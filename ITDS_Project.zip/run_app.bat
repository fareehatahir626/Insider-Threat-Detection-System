@echo off
echo =======================================================
echo    Starting Insider Threat Detection System (ITDS)
echo =======================================================

:: Check if Node.js is installed
node -v >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not installed!
    echo Please install Node.js from https://nodejs.org/ and try again.
    pause
    exit /b
)

:: Install Node modules if they are missing
if not exist node_modules (
    echo [INFO] First time setup: Installing dependencies...
    call npm install
)

:: Start the server and open the browser
echo [INFO] Starting the Node server...
echo [INFO] The dashboard will open in your web browser shortly.
echo [INFO] Keep this black window open while using the app!
echo =======================================================

:: Give the server a second to start, then launch the browser
start "" http://localhost:3000

:: Run the server
node server.js
pause
